Abstract:
The addition of the tabcrumbs is meant to provide the user navigation for the current design.  It is meant to provide a secondary map to navigate the web app.  They essentially provide a pseudo-structure for the user to navigate the website. -> Requires only minor modifications. (Installing "street signs")


Files:

SF_sitemap.pdf
This is an outline of the hierarchy of the pages.  This model fits almost perfectly with the current state of the website.  With the addition of a Mentees page, the current website will not need much modification.

SF_home_tabcrumbs_wireframe.jpg
This is a mockup wireframe of the tabcrumbs for the header of the home page.  They can either, be displayed static at the top of the page, or dynamically always resting at the top of the window (in the same way the current bar does.)

tabcrumbs_sketch.jpg
This was a quick sketch to understand the different tabcrumbs being displayed on the different pages of the website.  Note the second to last sketch.  This features the 10 activities as 10 tabs in the header.  Every activity completed by the menthe is bold. Every activity unread by the menthe is shaded/unread icon.

christine_mentees_page.jpg
This layout for separating each aspect of the mentees profile is excellent.  If time allows, the mentees tabcrumb could display: activities, profile, plan of study.
Home > Mentees > Mentee John Smith > Activities | Profile | Plan of Study

However, the space is limited and we might not be able to display the 10 activities in the tabcrumbs if this additional is shown:
Home > Mentees > Mentee John Smith > Activities > 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10
vs.
Home > Mentees > Mentee John Smith > 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10

Regards,
Steve McQuaid